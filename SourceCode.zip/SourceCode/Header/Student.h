#include "../Header/proto.h"
#include "../Header/Utility.h"
#include "../Header/Help.h"
//? for student
void Interface_ViewCoursesOfUser(Student *student_cur, Year *yearHead); // task 14
void ViewCoursesOfUser(Student *student_cur, Course *courseHead);       //? task 14
void Interface_ViewScoreBoardOfUser(Student *student_cur, Year *yearHead);
void ViewScoreboard(Account *accHead, Course *courseHead); //? task 24